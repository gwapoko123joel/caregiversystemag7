-- =================================================================
-- BANTAYAN CARE: AUDIT PATCHES
-- Applied by: Plotd. Audit 2026-05-24
-- Changes:
--   1. Secretary / Coordinator role support
--   2. daily_worklists table
--   3. Patients table — blood_type, allergies, emergency contact fields
--   4. RLS hardening — DELETE policies on caregivers
--   5. personnel_shifts RLS (was world-readable)
-- =================================================================

-- =================================================================
-- 1. SECRETARY ROLE — add to role check constraint
-- =================================================================

ALTER TABLE caregivers
  DROP CONSTRAINT IF EXISTS caregivers_role_check;

ALTER TABLE caregivers
  ADD CONSTRAINT caregivers_role_check
  CHECK (role IN ('caregiver', 'medical_practitioner', 'admin', 'secretary'));

-- =================================================================
-- 2. DAILY_WORKLISTS TABLE
-- =================================================================

CREATE TABLE IF NOT EXISTS daily_worklists (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  secretary_id    UUID NOT NULL REFERENCES caregivers(id) ON DELETE CASCADE,
  caregiver_id    UUID NOT NULL REFERENCES caregivers(id) ON DELETE CASCADE,
  patient_id      INTEGER NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
  scheduled_date  DATE NOT NULL DEFAULT CURRENT_DATE,
  visit_order     INTEGER NOT NULL DEFAULT 1,
  notes           TEXT,
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'completed', 'skipped')),
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  completed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_daily_worklists_date
  ON daily_worklists(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_daily_worklists_caregiver
  ON daily_worklists(caregiver_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_daily_worklists_secretary
  ON daily_worklists(secretary_id);

ALTER TABLE daily_worklists ENABLE ROW LEVEL SECURITY;

-- Secretary can do everything on their own worklists
DROP POLICY IF EXISTS "secretary_full_access_worklists" ON daily_worklists;
CREATE POLICY "secretary_full_access_worklists" ON daily_worklists
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM caregivers
      WHERE id = auth.uid() AND role = 'secretary' AND is_active = true
    )
  );

-- BHWs can read their own assigned worklist entries
DROP POLICY IF EXISTS "caregiver_read_own_worklist" ON daily_worklists;
CREATE POLICY "caregiver_read_own_worklist" ON daily_worklists
  FOR SELECT USING (caregiver_id = auth.uid());

-- BHWs can update status of their own entries (mark complete/skip)
DROP POLICY IF EXISTS "caregiver_update_own_worklist_status" ON daily_worklists;
CREATE POLICY "caregiver_update_own_worklist_status" ON daily_worklists
  FOR UPDATE USING (caregiver_id = auth.uid())
  WITH CHECK (caregiver_id = auth.uid());

-- Admin can read all worklists
DROP POLICY IF EXISTS "admin_read_all_worklists" ON daily_worklists;
CREATE POLICY "admin_read_all_worklists" ON daily_worklists
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregivers
      WHERE id = auth.uid() AND role = 'admin' AND is_active = true
    )
  );

-- Enable Realtime for worklist updates
DO
$$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'daily_worklists'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE daily_worklists;
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
END
$$;

-- =================================================================
-- 3. PATIENTS TABLE — new clinical fields
-- =================================================================

ALTER TABLE patients
  ADD COLUMN IF NOT EXISTS blood_type TEXT
    CHECK (blood_type IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
  ADD COLUMN IF NOT EXISTS allergies TEXT,
  ADD COLUMN IF NOT EXISTS emergency_contact_number TEXT;

-- emergency_contact column may already exist — ensure it does
ALTER TABLE patients
  ADD COLUMN IF NOT EXISTS emergency_contact TEXT;

-- =================================================================
-- 4. RLS HARDENING — caregivers table DELETE policy
-- =================================================================

-- Previously there was no explicit DELETE deny for anon users.
-- Supabase returns 204 even when 0 rows are deleted if no DELETE policy exists.
-- Adding an explicit deny policy for anon and a whitelist for admin.

DROP POLICY IF EXISTS "admin_delete_caregivers" ON caregivers;
CREATE POLICY "admin_delete_caregivers" ON caregivers
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM caregivers self
      WHERE self.id = auth.uid() AND self.role = 'admin' AND self.is_active = true
    )
  );

-- Ensure the existing SELECT policy doesn't expose data to anon
-- The existing policy already requires auth.uid() match or active user — good.
-- Add explicit INSERT policy: only authenticated users can register
DROP POLICY IF EXISTS "authenticated_insert_caregivers" ON caregivers;
CREATE POLICY "authenticated_insert_caregivers" ON caregivers
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- =================================================================
-- 5. PERSONNEL_SHIFTS RLS — was world-readable
-- =================================================================

ALTER TABLE personnel_shifts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "shift_owner_access" ON personnel_shifts;
CREATE POLICY "shift_owner_access" ON personnel_shifts
  FOR ALL USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM caregivers
      WHERE id = auth.uid() AND role IN ('admin', 'secretary') AND is_active = true
    )
  );

-- =================================================================
-- 6. BARANGAY_POPULATION_HEALTH RLS
-- =================================================================

ALTER TABLE barangay_population_health ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "authenticated_read_population_health" ON barangay_population_health;
CREATE POLICY "authenticated_read_population_health" ON barangay_population_health
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM caregivers WHERE id = auth.uid() AND is_active = true
    )
  );

-- =================================================================
-- VERIFICATION
-- =================================================================

DO
$$
DECLARE
  missing_items TEXT[] := ARRAY[]::TEXT[];
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'daily_worklists') THEN
    missing_items := array_append(missing_items, 'daily_worklists table');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'patients' AND column_name = 'blood_type') THEN
    missing_items := array_append(missing_items, 'patients.blood_type column');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'patients' AND column_name = 'allergies') THEN
    missing_items := array_append(missing_items, 'patients.allergies column');
  END IF;

  IF array_length(missing_items, 1) > 0 THEN
    RAISE WARNING 'AUDIT PATCH INCOMPLETE - Missing: %', array_to_string(missing_items, ', ');
  ELSE
    RAISE NOTICE 'AUDIT PATCHES APPLIED SUCCESSFULLY';
  END IF;
END
$$;
