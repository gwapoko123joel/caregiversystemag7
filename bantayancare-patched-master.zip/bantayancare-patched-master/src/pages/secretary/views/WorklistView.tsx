import { useEffect, useState } from 'react';
import { Plus, Trash2, GripVertical, CheckCircle2, Clock, SkipForward } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../../../lib/supabaseClient';
import { useAuth } from '../../../hooks/useAuth';

interface BHW { id: string; full_name: string; unique_access_id: string; }
interface Patient { patient_id: number; first_name: string; last_name: string; }
interface WorklistEntry {
  id: string;
  caregiver_id: string;
  patient_id: number;
  visit_order: number;
  notes: string;
  status: 'pending' | 'completed' | 'skipped';
  caregiver?: { full_name: string };
  patient?: { first_name: string; last_name: string };
}

export default function WorklistView() {
  const { user } = useAuth();
  const today = new Date().toISOString().split('T')[0];

  const [bhws, setBhws] = useState<BHW[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [worklist, setWorklist] = useState<WorklistEntry[]>([]);
  const [selectedBHW, setSelectedBHW] = useState('');
  const [selectedPatient, setSelectedPatient] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      const [bhwRes, patientRes, worklistRes] = await Promise.all([
        supabase.from('caregivers').select('id, full_name, unique_access_id').eq('role', 'caregiver').eq('is_active', true),
        supabase.from('patients').select('patient_id, first_name, last_name').eq('registration_status', 'active'),
        supabase.from('daily_worklists')
          .select('*, caregiver:caregivers!caregiver_id(full_name), patient:patients!patient_id(first_name, last_name)')
          .eq('scheduled_date', today)
          .order('visit_order'),
      ]);
      setBhws(bhwRes.data ?? []);
      setPatients(patientRes.data ?? []);
      setWorklist((worklistRes.data ?? []) as WorklistEntry[]);
      setLoading(false);
    }
    load();
  }, [today]);

  async function addEntry() {
    if (!selectedBHW || !selectedPatient || !user) return;
    setSaving(true);
    const nextOrder = worklist.filter(w => w.caregiver_id === selectedBHW).length + 1;

    const { data, error } = await supabase.from('daily_worklists').insert({
      secretary_id: user.id,
      caregiver_id: selectedBHW,
      patient_id: parseInt(selectedPatient),
      scheduled_date: today,
      visit_order: nextOrder,
      notes: notes.trim() || null,
      status: 'pending',
    }).select('*, caregiver:caregivers!caregiver_id(full_name), patient:patients!patient_id(first_name, last_name)').single();

    if (error) { toast.error(error.message); }
    else { setWorklist(prev => [...prev, data as WorklistEntry]); setSelectedPatient(''); setNotes(''); toast.success('Visit added to worklist.'); }
    setSaving(false);
  }

  async function updateStatus(id: string, status: 'completed' | 'skipped') {
    const { error } = await supabase.from('daily_worklists').update({ status }).eq('id', id);
    if (error) { toast.error(error.message); return; }
    setWorklist(prev => prev.map(w => w.id === id ? { ...w, status } : w));
  }

  async function removeEntry(id: string) {
    const { error } = await supabase.from('daily_worklists').delete().eq('id', id);
    if (error) { toast.error(error.message); return; }
    setWorklist(prev => prev.filter(w => w.id !== id));
    toast.success('Entry removed.');
  }

  const statusIcon = { pending: <Clock size={14} className="text-amber-400" />, completed: <CheckCircle2 size={14} className="text-emerald-400" />, skipped: <SkipForward size={14} className="text-slate-500" /> };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Daily <span className="text-sky-400">Worklist</span></h2>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mt-1">{today}</p>
      </div>

      {/* Add Entry */}
      <div className="bg-slate-900/40 border border-white/5 rounded-3xl p-6 space-y-4">
        <h3 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Assign Visit</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select value={selectedBHW} onChange={e => setSelectedBHW(e.target.value)}
            className="bg-slate-950/50 border border-white/10 rounded-2xl py-3 px-4 text-sm text-white outline-none [color-scheme:dark]">
            <option value="">Select BHW...</option>
            {bhws.map(b => <option key={b.id} value={b.id}>{b.full_name} ({b.unique_access_id})</option>)}
          </select>
          <select value={selectedPatient} onChange={e => setSelectedPatient(e.target.value)}
            className="bg-slate-950/50 border border-white/10 rounded-2xl py-3 px-4 text-sm text-white outline-none [color-scheme:dark]">
            <option value="">Select Patient...</option>
            {patients.map(p => <option key={p.patient_id} value={p.patient_id}>{p.first_name} {p.last_name}</option>)}
          </select>
          <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Visit notes (optional)"
            className="bg-slate-950/50 border border-white/10 rounded-2xl py-3 px-4 text-sm text-white outline-none placeholder:text-slate-700" />
        </div>
        <button onClick={addEntry} disabled={!selectedBHW || !selectedPatient || saving}
          className="flex items-center gap-2 px-6 py-3 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
          <Plus size={16} /> Add to Worklist
        </button>
      </div>

      {/* Worklist */}
      {loading ? (
        <div className="text-center text-slate-500 py-12">Loading today's worklist...</div>
      ) : worklist.length === 0 ? (
        <div className="text-center text-slate-500 py-12 border border-dashed border-white/10 rounded-3xl">
          <ClipboardList size={32} className="mx-auto mb-3 text-slate-700" />
          <p className="font-bold text-sm">No visits scheduled for today.</p>
          <p className="text-xs mt-1">Use the form above to assign visits to BHWs.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {worklist.map(entry => (
            <div key={entry.id} className="flex items-center gap-4 bg-slate-900/40 border border-white/5 rounded-2xl px-4 py-3">
              <GripVertical size={16} className="text-slate-700 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate">
                  {entry.patient?.first_name} {entry.patient?.last_name}
                </p>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest">
                  BHW: {entry.caregiver?.full_name} · #{entry.visit_order}
                </p>
                {entry.notes && <p className="text-xs text-slate-400 mt-0.5 italic">{entry.notes}</p>}
              </div>
              <div className="flex items-center gap-2">
                {statusIcon[entry.status]}
                {entry.status === 'pending' && (
                  <>
                    <button onClick={() => updateStatus(entry.id, 'completed')} className="text-[9px] font-black uppercase text-emerald-400 hover:text-emerald-300 px-2 py-1 rounded-lg border border-emerald-500/20 hover:border-emerald-500/50 transition-all">Done</button>
                    <button onClick={() => updateStatus(entry.id, 'skipped')} className="text-[9px] font-black uppercase text-slate-500 hover:text-slate-300 px-2 py-1 rounded-lg border border-white/10 transition-all">Skip</button>
                  </>
                )}
                <button onClick={() => removeEntry(entry.id)} className="text-slate-700 hover:text-rose-400 transition-colors p-1">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
