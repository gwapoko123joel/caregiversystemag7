import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ClipboardList, Users, GitBranch, LayoutDashboard, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import WorklistView from './views/WorklistView';
import AssignmentsView from './views/AssignmentsView';
import SecretaryOverview from './views/SecretaryOverview';

const NAV_ITEMS = [
  { to: 'overview',     label: 'Overview',        icon: LayoutDashboard },
  { to: 'worklist',     label: 'Daily Worklist',   icon: ClipboardList },
  { to: 'assignments',  label: 'BHW Assignments',  icon: Users },
  { to: 'referrals',    label: 'Referral Routing', icon: GitBranch },
];

export default function SecretaryDashboard() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  async function handleSignOut() {
    await signOut();
    navigate('/login');
  }

  return (
    <div className="min-h-screen bg-[#020617] flex">
      {/* ── SIDEBAR ── */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-slate-900/80 backdrop-blur border-r border-white/5
        flex flex-col transition-transform duration-300
        ${mobileOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:static lg:flex
      `}>
        <div className="p-6 border-b border-white/5">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">BantayanCare</p>
          <h1 className="text-lg font-black text-white uppercase tracking-tight leading-none mt-1">Coordinator</h1>
          <p className="text-[10px] text-sky-400 font-bold mt-1 truncate">{profile?.full_name}</p>
          <p className="text-[9px] text-slate-600 font-mono">{profile?.unique_access_id}</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all ${
                  isActive
                    ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
                    : 'text-slate-500 hover:text-white hover:bg-white/5'
                }`
              }
            >
              <Icon size={16} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest text-slate-500 hover:text-rose-400 hover:bg-rose-500/5 transition-all"
          >
            <LogOut size={16} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* ── MAIN ── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center justify-between p-4 border-b border-white/5 bg-slate-900/80 backdrop-blur">
          <button onClick={() => setMobileOpen(true)} className="p-2 text-slate-400 hover:text-white">
            <Menu size={20} />
          </button>
          <span className="text-[10px] font-black text-white uppercase tracking-widest">Coordinator</span>
          <div className="w-9" />
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <Routes>
            <Route index element={<Navigate to="overview" replace />} />
            <Route path="overview"     element={<SecretaryOverview />} />
            <Route path="worklist"     element={<WorklistView />} />
            <Route path="assignments"  element={<AssignmentsView />} />
            <Route path="referrals"    element={<ReferralRoutingPlaceholder />} />
            <Route path="*"            element={<Navigate to="overview" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function ReferralRoutingPlaceholder() {
  return (
    <div className="flex flex-col items-center justify-center h-64 text-center">
      <GitBranch size={40} className="text-slate-700 mb-4" />
      <h3 className="text-white font-black uppercase tracking-tight text-xl">Referral Routing</h3>
      <p className="text-slate-500 text-sm mt-2">Incoming referrals from field BHWs will appear here.</p>
    </div>
  );
}
