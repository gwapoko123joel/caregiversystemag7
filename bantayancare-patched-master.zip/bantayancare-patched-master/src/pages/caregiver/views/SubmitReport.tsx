import { useState, useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { supabase } from '../../../lib/supabaseClient'
import { useAuth } from '../../../hooks/useAuth'
import ReportView from './ReportView' 
import { UserSearch, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react'

export default function SubmitReport() {
  const { user } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  // 1. Get Patient from Navigation State (passed from History/Roster)
  const [patient] = useState<any>(location.state?.patient || null)

  // 2. Form State
  const [form, setForm] = useState({
    blood_pressure: '',
    heart_rate: '',
    temperature: '',
    oxygen_saturation: '',
    physical_status: 'stable' as 'stable' | 'warning' | 'critical',
    notes: ''
  })

  // 3. Status States
  const [submitting, setSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  
  // --- LOCAL STORAGE DRAFT SAFETY ---
  useEffect(() => {
    if (!patient) return;
    const draft = localStorage.getItem(`draft_notes_${patient.patient_id}`);
    if (draft) setField('notes', draft);
  }, [patient?.patient_id]);

  const setField = (key: string, val: any) => {
    setForm(prev => ({ ...prev, [key]: val }))
    if (key === 'notes' && patient) {
      localStorage.setItem(`draft_notes_${patient.patient_id}`, val);
    }
  }

  // Handle Image Selection
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      setImagePreview(URL.createObjectURL(file))
    }
  }

  const removeImage = () => {
    setImageFile(null)
    setImagePreview(null)
  }

  // 4. THE SUBMIT LOGIC
  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault()
    if (!user || !patient) return

    setSubmitting(true)

    try {
      let imageUrl = null

      // 1. Upload Image (If exists)
      if (imageFile) {
        const fileName = `${patient.patient_id}/${Date.now()}.jpg`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('patient-photos')
          .upload(fileName, imageFile)
        if (uploadError) throw uploadError
        imageUrl = uploadData.path
      }

      // 2. Insert the Monitoring Log
      const { data: logData, error: insertError } = await supabase
        .from('patient_monitoring_logs')
        .insert({
          patient_id: patient.patient_id,
          caregiver_id: user.id,
          physical_status: form.physical_status,
          notes: form.notes,
          image_url: imageUrl,
          vital_signs: {
            blood_pressure: form.blood_pressure,
            heart_rate: form.heart_rate,
            temperature: form.temperature,
            oxygen_saturation: form.oxygen_saturation
          }
        })
        .select()
        .single()

      if (insertError) throw insertError

      await supabase.from('activity_logs').insert({
        user_id: user?.id,
        user_type: 'caregiver',
        action: 'VITALS_SUBMITTED',
        details: { 
          patient_name: `${patient.first_name} ${patient.last_name}`,
          status: form.physical_status 
        }
      });

      // 3. BROADCAST ALERT LOGIC
      const sys = parseInt(form.blood_pressure.split('/')[0])
      const o2 = parseInt(form.oxygen_saturation)

      const isCritical = sys > 160 || o2 < 90 || form.physical_status === 'critical'
      const isWarning = sys > 140 || o2 < 95 || form.physical_status === 'warning'

      if (isCritical || isWarning) {
        const { error: alertError } = await supabase
          .from('alerts')
          .insert({
            patient_id: Number(patient.patient_id), 
            log_id: Number(logData.log_id),
            severity: isCritical ? 'critical' : 'warning',
            description: `Emergency: BP ${form.blood_pressure} | O2 ${form.oxygen_saturation}%`,
            is_resolved: false
          })

        if (alertError) {
          alert("DATABASE REJECTED ALERT: " + alertError.message);
        }

        await supabase
          .from('patients')
          .update({ status: isCritical ? 'critical' : 'warning' })
          .eq('patient_id', patient.patient_id);
      } else {
        await supabase
          .from('patients')
          .update({ status: 'active' })
          .eq('patient_id', patient.patient_id);
      }

      setSubmitSuccess(true)
      if (patient) localStorage.removeItem(`draft_notes_${patient.patient_id}`);

    } catch (err: any) {
      console.error("Critical System Error:", err)
      alert(err.message || "Connection failed. Please check network.")
    } finally {
      setSubmitting(false)
    }
  }

  // Success Overlay logic
  if (submitSuccess) {
    return (
      // Centering wrapper to ensure it doesn't stretch
      <div className="flex items-center justify-center min-h-[70vh] px-4 animate-in fade-in zoom-in duration-500">
        <div className="max-w-lg w-full bg-slate-900/40 backdrop-blur-xl border border-emerald-500/30 rounded-[40px] p-10 md:p-12 text-center shadow-2xl relative overflow-hidden">
          
          {/* Decorative Background Shield */}
          <div className="absolute -top-12 -right-12 opacity-5 text-emerald-500 pointer-events-none">
             <ShieldCheck size={240} />
          </div>

          {/* Visual Success Indicator */}
          <div className="w-20 h-20 bg-emerald-500/10 rounded-[2rem] flex items-center justify-center mx-auto mb-8 border border-emerald-500/20 relative shadow-[0_0_30px_rgba(16,185,129,0.1)]">
            <div className="absolute inset-0 rounded-[2rem] bg-emerald-500 animate-ping opacity-10" />
            <CheckCircle2 size={40} className="text-emerald-500" />
          </div>

          <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tighter mb-3">
            Telemetry Synchronized
          </h2>
          
          <p className="text-emerald-400 font-bold uppercase text-[9px] tracking-[0.3em] mb-6">
            Status: Transmission Successful
          </p>
          
          <p className="text-sm text-slate-400 leading-relaxed mb-10 px-4">
            Clinical data for <span className="text-white font-bold">{patient.first_name} {patient.last_name}</span> has been securely broadcasted to the medical practitioner network.
          </p> 

          <div className="bg-slate-950/50 rounded-3xl p-5 border border-white/5 mb-10 grid grid-cols-2 gap-4">
             <div className="text-left border-r border-white/5 pr-4">
                <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest mb-1">Node Identifier</p>
                <p className="text-[10px] font-mono font-bold text-slate-400">BANTAYAN-NODE-01</p>
             </div>
             <div className="text-right pl-4">
                <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest mb-1">Sync Timestamp</p>
                <p className="text-[10px] font-mono font-bold text-slate-400">
                  {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </p>
             </div>
          </div>

          <button
            onClick={() => navigate('/dashboard/caregiver/history')}
            className="w-full py-5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-xl shadow-emerald-500/20 active:scale-[0.98] flex items-center justify-center gap-3"
          >
            Return to Patient Registry <ArrowRight size={16} />
          </button>
        </div>
      </div>
    )
  }

  // 5. If no patient is selected, show a "Select Patient" state
  if (!patient) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-card border border-card-border rounded-[32px] text-center max-w-2xl mx-auto mt-10">
        <div className="w-20 h-20 bg-sky-500/10 rounded-full flex items-center justify-center mb-6">
          <UserSearch size={40} className="text-sky-500" />
        </div>
        <h2 className="text-xl font-black text-text-main uppercase tracking-widest mb-2">No Patient Selected</h2>
        <p className="text-sidebar-text-muted mb-8 text-sm">
          To ensure medical accuracy, please select a patient from your roster before submitting a report.
        </p>
        <button
          onClick={() => navigate('/dashboard/caregiver/history')}
          className="px-8 py-4 bg-sky-500 hover:bg-sky-400 text-white rounded-2xl text-xs font-black uppercase tracking-widest transition-all"
        >
          Go to Patient Roster
        </button>
      </div>
    )
  }

  return (
    <ReportView
      patient={patient}
      form={form}
      setField={setField}
      handleSubmit={handleSubmit}
      submitting={submitting}
      imagePreview={imagePreview}
      handleImageChange={handleImageChange}
      removeImage={removeImage}
      onBack={() => navigate('/dashboard/caregiver/history')}
    />
  )
}
