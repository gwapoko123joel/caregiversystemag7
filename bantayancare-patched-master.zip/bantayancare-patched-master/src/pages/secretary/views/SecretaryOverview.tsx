import { useEffect, useState } from 'react';
import { ClipboardList, Users, AlertCircle, CheckCircle2 } from 'lucide-react';
import { supabase } from '../../../lib/supabaseClient';

interface Stats {
  totalBHWs: number;
  totalPatients: number;
  pendingWorklists: number;
  completedToday: number;
}

export default function SecretaryOverview() {
  const [stats, setStats] = useState<Stats>({ totalBHWs: 0, totalPatients: 0, pendingWorklists: 0, completedToday: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      const today = new Date().toISOString().split('T')[0];

      const [bhwRes, patientRes, pendingRes, completedRes] = await Promise.all([
        supabase.from('caregivers').select('id', { count: 'exact', head: true }).eq('role', 'caregiver').eq('is_active', true),
        supabase.from('patients').select('patient_id', { count: 'exact', head: true }).eq('registration_status', 'active'),
        supabase.from('daily_worklists').select('id', { count: 'exact', head: true }).eq('scheduled_date', today).eq('status', 'pending'),
        supabase.from('daily_worklists').select('id', { count: 'exact', head: true }).eq('scheduled_date', today).eq('status', 'completed'),
      ]);

      setStats({
        totalBHWs: bhwRes.count ?? 0,
        totalPatients: patientRes.count ?? 0,
        pendingWorklists: pendingRes.count ?? 0,
        completedToday: completedRes.count ?? 0,
      });
      setLoading(false);
    }
    fetchStats();
  }, []);

  const cards = [
    { label: 'Active BHWs',       value: stats.totalBHWs,       icon: Users,         color: 'sky' },
    { label: 'Active Patients',    value: stats.totalPatients,    icon: ClipboardList, color: 'emerald' },
    { label: 'Pending Visits Today', value: stats.pendingWorklists, icon: AlertCircle,   color: 'amber' },
    { label: 'Completed Today',    value: stats.completedToday,   icon: CheckCircle2,  color: 'green' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Operations <span className="text-sky-400">Overview</span></h2>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mt-1">Today's Coverage Status</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-slate-900/40 border border-white/5 rounded-3xl p-6">
            <Icon size={20} className={`text-${color}-400 mb-4`} />
            <p className="text-3xl font-black text-white">{loading ? '—' : value}</p>
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">{label}</p>
          </div>
        ))}
      </div>

      <div className="bg-slate-900/40 border border-white/5 rounded-3xl p-8">
        <h3 className="text-xs font-black text-white uppercase tracking-[0.2em] mb-4">What This Dashboard Does</h3>
        <ul className="space-y-3 text-sm text-slate-400">
          <li className="flex gap-3"><span className="text-sky-400 font-bold">01</span> Build and assign daily patient visit lists to specific BHWs each morning.</li>
          <li className="flex gap-3"><span className="text-sky-400 font-bold">02</span> Rebalance caseloads when BHWs are unavailable or overloaded.</li>
          <li className="flex gap-3"><span className="text-sky-400 font-bold">03</span> Route referral requests from BHWs to the appropriate doctor.</li>
          <li className="flex gap-3"><span className="text-sky-400 font-bold">04</span> Monitor which patients have been visited and which are outstanding.</li>
        </ul>
      </div>
    </div>
  );
}
