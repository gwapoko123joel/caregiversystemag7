import { useNavigate } from 'react-router-dom';
import { Home, AlertTriangle } from 'lucide-react';

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center text-center px-6">
      <div className="w-20 h-20 bg-rose-500/10 border border-rose-500/20 rounded-[2rem] flex items-center justify-center mb-8">
        <AlertTriangle size={40} className="text-rose-400" />
      </div>
      <h1 className="text-6xl font-black text-white uppercase tracking-tighter leading-none">404</h1>
      <p className="text-[10px] font-black text-rose-400 uppercase tracking-[0.4em] mt-3 mb-2">Page Not Found</p>
      <p className="text-slate-500 text-sm max-w-sm mt-2 mb-10">
        The page you're looking for doesn't exist or you don't have permission to access it.
      </p>
      <button
        onClick={() => navigate('/')}
        className="flex items-center gap-2 px-8 py-4 bg-sky-500 hover:bg-sky-400 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-xl shadow-sky-500/20"
      >
        <Home size={16} /> Return to Home
      </button>
    </div>
  );
}
