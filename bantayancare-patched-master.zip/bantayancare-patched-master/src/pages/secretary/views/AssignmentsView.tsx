import { useEffect, useState } from 'react';
import { Users, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '../../../lib/supabaseClient';

interface Assignment {
  id: string;
  caregiver_id: string;
  patient_id: number;
  status: string;
  caregiver: { full_name: string; unique_access_id: string } | null;
  patient: { first_name: string; last_name: string } | null;
}

interface BHW { id: string; full_name: string; unique_access_id: string; }

export default function AssignmentsView() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [bhws, setBhws] = useState<BHW[]>([]);
  const [loading, setLoading] = useState(true);
  const [reassigning, setReassigning] = useState<number | null>(null);
  const [targetBHW, setTargetBHW] = useState<Record<number, string>>({});

  useEffect(() => {
    async function load() {
      const [aRes, bRes] = await Promise.all([
        supabase.from('caregiver_patient_assignments')
          .select('*, caregiver:caregivers!caregiver_id(full_name, unique_access_id), patient:patients!patient_id(first_name, last_name)')
          .eq('status', 'active'),
        supabase.from('caregivers').select('id, full_name, unique_access_id').eq('role', 'caregiver').eq('is_active', true),
      ]);
      setAssignments((aRes.data ?? []) as Assignment[]);
      setBhws(bRes.data ?? []);
      setLoading(false);
    }
    load();
  }, []);

  async function reassign(patientId: number, currentAssignmentId: string) {
    const newBHW = targetBHW[patientId];
    if (!newBHW) return;
    setReassigning(patientId);

    const { error } = await supabase.from('caregiver_patient_assignments')
      .update({ caregiver_id: newBHW })
      .eq('id', currentAssignmentId);

    if (error) { toast.error(error.message); }
    else {
      const newBHWData = bhws.find(b => b.id === newBHW);
      setAssignments(prev => prev.map(a =>
        a.id === currentAssignmentId
          ? { ...a, caregiver_id: newBHW, caregiver: newBHWData ? { full_name: newBHWData.full_name, unique_access_id: newBHWData.unique_access_id } : a.caregiver }
          : a
      ));
      toast.success('Patient reassigned successfully.');
    }
    setReassigning(null);
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-black text-white uppercase tracking-tighter">BHW <span className="text-sky-400">Assignments</span></h2>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mt-1">Active patient-caregiver assignments</p>
      </div>

      {loading ? (
        <div className="text-center text-slate-500 py-12">Loading assignments...</div>
      ) : assignments.length === 0 ? (
        <div className="text-center text-slate-500 py-12 border border-dashed border-white/10 rounded-3xl">
          <Users size={32} className="mx-auto mb-3 text-slate-700" />
          <p className="font-bold text-sm">No active assignments found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {assignments.map(a => (
            <div key={a.id} className="flex flex-col md:flex-row md:items-center gap-4 bg-slate-900/40 border border-white/5 rounded-2xl px-5 py-4">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white">{a.patient?.first_name} {a.patient?.last_name}</p>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-0.5">
                  Currently assigned to: <span className="text-sky-400">{a.caregiver?.full_name}</span> ({a.caregiver?.unique_access_id})
                </p>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={targetBHW[a.patient_id] ?? ''}
                  onChange={e => setTargetBHW(prev => ({ ...prev, [a.patient_id]: e.target.value }))}
                  className="bg-slate-950/50 border border-white/10 rounded-xl py-2 px-3 text-xs text-white outline-none [color-scheme:dark]"
                >
                  <option value="">Reassign to...</option>
                  {bhws.filter(b => b.id !== a.caregiver_id).map(b => (
                    <option key={b.id} value={b.id}>{b.full_name} ({b.unique_access_id})</option>
                  ))}
                </select>
                <button
                  onClick={() => reassign(a.patient_id, a.id)}
                  disabled={!targetBHW[a.patient_id] || reassigning === a.patient_id}
                  className="flex items-center gap-1.5 px-3 py-2 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-sky-500/20 disabled:opacity-40 transition-all"
                >
                  <RefreshCw size={12} className={reassigning === a.patient_id ? 'animate-spin' : ''} />
                  Reassign
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
